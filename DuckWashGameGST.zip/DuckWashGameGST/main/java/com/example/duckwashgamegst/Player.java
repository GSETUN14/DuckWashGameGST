package com.example.duckwashgamegst;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

public class Player {
    private int x, y;
    private Bitmap playerBitmap;
    private int width, height;
    private int screenHeight;
    private String playerName; // Nombre del jugador
    private Paint textPaint; // Pintura para el texto

    public Player(Context context, String playerName, int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.playerName = playerName;

        // Cargar la imagen del jugador
        playerBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.player);
        playerBitmap = Bitmap.createScaledBitmap(playerBitmap, width, height, false);
        this.screenHeight = context.getResources().getDisplayMetrics().heightPixels;

        // Configurar la pintura del texto
        textPaint = new Paint();
        textPaint.setColor(0xFF000000); // Color negro
        textPaint.setTextSize(40); // Tamaño de texto
        textPaint.setTextAlign(Paint.Align.CENTER); // Centrar el texto
    }

    // Método para dibujar al jugador
    public void draw(Canvas canvas) {
        canvas.drawBitmap(playerBitmap, x, y, null);
        // Dibujar el nombre del jugador debajo del muñeco
        canvas.drawText(playerName, x + width / 2, y + height + 40, textPaint);
    }

    // Método para mover al jugador
    public void move(int dy) {
        y += dy;
        if (y < 0) y = 0;
        if (y + height > screenHeight) {
            y = screenHeight - height;
        }
    }

    // Método para establecer una nueva posición Y
    public void setY(int newY) {
        y = newY;
        if (y < 0) y = 0;
        if (y + height > screenHeight) {
            y = screenHeight - height;
        }
    }

    // Método para obtener los límites del jugador
    public Rect getBounds() {
        return new Rect(x, y, x + width, y + height);
    }

    // Métodos para obtener propiedades del jugador
    public int getX() { return x; }
    public int getY() { return y; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }

    // Método para establecer el nombre del jugador
    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }
}
