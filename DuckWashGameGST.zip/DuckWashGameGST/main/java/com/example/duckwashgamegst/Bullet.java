package com.example.duckwashgamegst;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

public class Bullet {
    private int x, y;
    private int speed = 15;
    private Paint paint;

    public Bullet(int x, int y) {
        this.x = x;
        this.y = y;
        paint = new Paint();
        paint.setColor(0xFF0000FF); // Color azul
    }

    public void update() {
        x -= speed; // Moverse a la derecha
    }

    public void draw(Canvas canvas) {
        canvas.drawRect(x, y, x + 20, y + 20, paint); // Dibuja un pequeño rectángulo
    }

    public int getX() {
        return x;
    }

    public Rect getBounds() {
        return new Rect(x, y, x + 10, y + 10);
    }
}
