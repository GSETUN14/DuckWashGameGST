package com.example.duckwashgamegst;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;

public class Enemy {
    private int x, y;
    private int width; // Ancho del enemigo
    private int height; // Alto del enemigo
    private Bitmap enemyImage; // Imagen del enemigo

    public Enemy(Context context, int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;

        // Cargar la imagen del enemigo
        enemyImage = BitmapFactory.decodeResource(context.getResources(), R.drawable.enemy); // Cambia 'enemy' por el nombre de tu imagen
        enemyImage = Bitmap.createScaledBitmap(enemyImage, width, height, false); // Redimensionar la imagen
    }

    public void update() {
        x += 5; // Moverse a la izquierda
    }

    public void draw(Canvas canvas) {
        canvas.drawBitmap(enemyImage, x, y, null); // Dibuja la imagen del enemigo
    }

    public int getX() {
        return x;
    }

    public Rect getBounds() {
        return new Rect(x, y, x + width, y + height);
    }
}
