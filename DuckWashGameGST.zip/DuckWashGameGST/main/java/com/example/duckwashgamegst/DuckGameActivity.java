package com.example.duckwashgamegst;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class DuckGameActivity extends AppCompatActivity {
    private DuckGameView duckGameView;
    private String playerName;
    private MediaPlayer mediaPlayer; // Variable para la música de fondo

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        duckGameView = findViewById(R.id.duckGameView);
        playerName = getIntent().getStringExtra("playerName");
        String difficulty = getIntent().getStringExtra("difficulty"); // Obtener la dificultad

        if (playerName == null || playerName.trim().isEmpty()) {
            playerName = "Jugador";
        }

        duckGameView.setPlayerName(playerName);
        duckGameView.setDifficulty(difficulty); // Asignar la dificultad a la vista
        duckGameView.setFocusableInTouchMode(true);

        // Configurar el botón "Inicio"
        Button homeButton = findViewById(R.id.homeButton);
        homeButton.setOnClickListener(v -> {
            // Inicia la pantalla de inicio y finaliza la actividad actual
            Intent intent = new Intent(DuckGameActivity.this, StartScreen.class);
            startActivity(intent);
            finish();
        });

        // Inicializar MediaPlayer con el archivo de audio ubicado en res/raw
        mediaPlayer = MediaPlayer.create(this, R.raw.tropical_music);
        mediaPlayer.setLooping(true); // Reproduce en bucle
    }

    @Override
    protected void onResume() {
        super.onResume();
        duckGameView.start();
        if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
            mediaPlayer.start(); // Iniciar la música
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        duckGameView.stop();
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause(); // Pausar la música
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release(); // Liberar recursos
            mediaPlayer = null;
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // Manejo de teclas para disparar
        if (keyCode == KeyEvent.KEYCODE_DPAD_UP) {
            duckGameView.shootBullet();
        } else if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
            duckGameView.shootBullet();
        } else if (keyCode == KeyEvent.KEYCODE_SPACE) {
            duckGameView.shootBullet();
        }
        return super.onKeyDown(keyCode, event);
    }
}
