package com.example.duckwashgamegst;

import android.graphics.RectF;

public class CollisionHandler {

    public static boolean checkCollision(Bullet bullet, Enemy enemy) {
        RectF bulletRect = new RectF(bullet.getBounds());  // Convertir Rect a RectF
        RectF enemyRect = new RectF(enemy.getBounds());    // Convertir Rect a RectF
        return RectF.intersects(bulletRect, enemyRect);  // Detectar colisión
    }
}
