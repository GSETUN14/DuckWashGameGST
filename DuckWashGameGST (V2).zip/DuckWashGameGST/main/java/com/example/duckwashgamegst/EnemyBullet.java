package com.example.duckwashgamegst;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

public class EnemyBullet {
    private int x, y;
    private int speed = 15;
    private Paint paint;

    public EnemyBullet(int x, int y) {
        this.x = x;
        this.y = y;
        paint = new Paint();
        paint.setColor(0xFFFF0000);
    }

    public void update() {
        x += speed;
    }

    public void draw(Canvas canvas) {
        canvas.drawRect(x, y, x + 20, y + 20, paint);
    }

    public int getX() {
        return x;
    }

    public Rect getBounds() {
        return new Rect(x, y, x + 10, y + 10);
    }
}
