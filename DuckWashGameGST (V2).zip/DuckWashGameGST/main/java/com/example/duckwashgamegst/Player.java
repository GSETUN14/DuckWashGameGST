package com.example.duckwashgamegst;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

public class Player {
    private int x, y;
    private Bitmap playerBitmap;
    private int width, height;
    private int screenHeight;
    private String playerName;
    private Paint textPaint;

    public Player(Context context, String playerName, int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.playerName = playerName;


        playerBitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.player);
        playerBitmap = Bitmap.createScaledBitmap(playerBitmap, width, height, false);
        this.screenHeight = context.getResources().getDisplayMetrics().heightPixels;


        textPaint = new Paint();
        textPaint.setColor(0xFF000000);
        textPaint.setTextSize(40);
        textPaint.setTextAlign(Paint.Align.CENTER);
    }


    public void draw(Canvas canvas) {
        canvas.drawBitmap(playerBitmap, x, y, null);
        canvas.drawText(playerName, x + width / 2, y + height + 40, textPaint);
    }


    public void move(int dy) {
        y += dy;
        if (y < 0) y = 0;
        if (y + height > screenHeight) {
            y = screenHeight - height;
        }
    }


    public void setY(int newY) {
        y = newY;
        if (y < 0) y = 0;
        if (y + height > screenHeight) {
            y = screenHeight - height;
        }
    }


    public Rect getBounds() {
        return new Rect(x, y, x + width, y + height);
    }


    public int getX() { return x; }
    public int getY() { return y; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }


    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }
}
