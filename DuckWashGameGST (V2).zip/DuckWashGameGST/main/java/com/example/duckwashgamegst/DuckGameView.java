package com.example.duckwashgamegst;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class DuckGameView extends SurfaceView implements Runnable {
    private Thread gameThread;
    private boolean isRunning;
    private boolean isGameOver;
    private Player player;
    private ArrayList<Enemy> enemies;
    private ArrayList<Bullet> bullets;

    private ArrayList<EnemyBullet> enemyBullets;
    private Bitmap backgroundImage;
    private long lastEnemyTime;
    private long lastEnemyBulletTime;
    private final long enemyBulletInterval = 3000;
    private Random random;
    private int score;
    private String playerName;

    private String difficulty = "easy";

    public DuckGameView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initializeGame();
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
        if (player != null) {
            player.setPlayerName(playerName);
        }
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    private void initializeGame() {
        player = new Player(getContext(), playerName, 2200, 300, 100, 100);
        enemies = new ArrayList<>();
        bullets = new ArrayList<>();
        enemyBullets = new ArrayList<>();
        random = new Random();
        lastEnemyTime = System.currentTimeMillis();
        lastEnemyBulletTime = System.currentTimeMillis();
        backgroundImage = BitmapFactory.decodeResource(getResources(), R.drawable.background);
        isGameOver = false;
        score = 0;
    }

    @Override
    public void run() {
        while (isRunning) {
            update();
            draw();
            try {
                Thread.sleep(1000 / 60); // 60 FPS
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void update() {
        if (isGameOver) {
            return;
        }

        Iterator<Enemy> enemyIterator = enemies.iterator();
        while (enemyIterator.hasNext()) {
            Enemy enemy = enemyIterator.next();
            enemy.update();
            if (enemy.getX() > getWidth()) {
                enemyIterator.remove();
            }
        }

        Iterator<Bullet> bulletIterator = bullets.iterator();
        while (bulletIterator.hasNext()) {
            Bullet bullet = bulletIterator.next();
            bullet.update();
            if (bullet.getX() > getWidth()) {
                bulletIterator.remove();
            }
        }

        if (System.currentTimeMillis() - lastEnemyTime > 2000) {
            int randomY = random.nextInt(getHeight() - 80);
            int enemyWidth = 100;
            int enemyHeight = 100;
            enemies.add(new Enemy(getContext(), -enemyWidth, randomY, enemyWidth, enemyHeight));
            lastEnemyTime = System.currentTimeMillis();
        }


        if ("hard".equalsIgnoreCase(difficulty)) {
            if (System.currentTimeMillis() - lastEnemyBulletTime > enemyBulletInterval) {
                for (Enemy enemy : enemies) {
                    int bulletX = enemy.getBounds().right;
                    int bulletY = enemy.getBounds().centerY() - 5;
                    enemyBullets.add(new EnemyBullet(bulletX, bulletY));
                }
                lastEnemyBulletTime = System.currentTimeMillis();
            }
        }

        Iterator<EnemyBullet> enemyBulletIterator = enemyBullets.iterator();
        while (enemyBulletIterator.hasNext()) {
            EnemyBullet enemyBullet = enemyBulletIterator.next();
            enemyBullet.update();
            if (enemyBullet.getX() > getWidth()) {
                enemyBulletIterator.remove();
            }
        }

        detectCollisions();

        checkPlayerCollision();


        for (EnemyBullet enemyBullet : enemyBullets) {
            if (enemyBullet.getBounds().intersect(player.getBounds())) {
                isGameOver = true;
                break;
            }
        }
    }

    private void detectCollisions() {
        Iterator<Enemy> enemyIterator = enemies.iterator();
        while (enemyIterator.hasNext()) {
            Enemy enemy = enemyIterator.next();
            Iterator<Bullet> bulletIterator = bullets.iterator();
            while (bulletIterator.hasNext()) {
                Bullet bullet = bulletIterator.next();
                if (enemy.getBounds().intersect(bullet.getBounds())) {
                    enemyIterator.remove();
                    bulletIterator.remove();
                    score += 10;
                    break;
                }
            }
        }
    }

    private void checkPlayerCollision() {
        for (Enemy enemy : enemies) {
            if (enemy.getBounds().intersect(player.getBounds())) {
                isGameOver = true;
                break;
            }
        }
    }

    private void draw() {
        if (getHolder().getSurface().isValid()) {
            Canvas canvas = getHolder().lockCanvas();
            Bitmap scaledBackground = Bitmap.createScaledBitmap(backgroundImage, getWidth(), getHeight(), true);
            canvas.drawBitmap(scaledBackground, 0, 0, null);
            player.draw(canvas);
            for (Enemy enemy : enemies) {
                enemy.draw(canvas);
            }
            for (Bullet bullet : bullets) {
                bullet.draw(canvas);
            }
            for (EnemyBullet enemyBullet : enemyBullets) {
                enemyBullet.draw(canvas);
            }
            Paint scorePaint = new Paint();
            scorePaint.setColor(0xFF000000);
            scorePaint.setTextSize(50);
            canvas.drawText("Puntos: " + score, 50, 100, scorePaint);
            if (isGameOver) {
                Paint paint = new Paint();
                paint.setColor(0xFFFF0000);
                paint.setTextSize(100);
                String gameOverText = "GAME OVER";
                String restartText = "Pulsa SPACE para reiniciar";
                float textWidth = paint.measureText(gameOverText);
                float restartWidth = paint.measureText(restartText);
                canvas.drawText(gameOverText, (getWidth() - textWidth) / 2, getHeight() / 2, paint);
                canvas.drawText(restartText, (getWidth() - restartWidth) / 2, getHeight() / 2 + 100, paint);
            }
            getHolder().unlockCanvasAndPost(canvas);
        }
    }

    public void start() {
        isRunning = true;
        gameThread = new Thread(this);
        gameThread.start();
    }

    public void stop() {
        isRunning = false;
    }

    public void restartGame() {
        isGameOver = false;
        initializeGame();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (isGameOver) {
            if (keyCode == KeyEvent.KEYCODE_SPACE) {
                restartGame();
                return true;
            }
            return true;
        }

        int dy = 0;
        if (keyCode == KeyEvent.KEYCODE_DPAD_UP) {
            dy = -5;
        } else if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
            dy = 5;
        }

        if (dy != 0) {
            player.move(dy);
        } else if (keyCode == KeyEvent.KEYCODE_SPACE) {
            shootBullet();
        }
        return true;
    }

    public void shootBullet() {
        int bulletSpawnX = player.getX() + player.getWidth() - 100;
        int bulletSpawnY = player.getY() + player.getHeight() / 2 - 5;
        bullets.add(new Bullet(bulletSpawnX, bulletSpawnY));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_MOVE) {
            player.setY((int) event.getY());
        }
        return true;
    }
}
